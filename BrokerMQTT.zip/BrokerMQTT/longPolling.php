<html>
	<head>
		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
		<script type="text/javascript" src="client.js"></script>
	</head>
	<body>
		<h3>Conteúdo</h3>
		<div id="response"></div>
		
	</body>
</html>